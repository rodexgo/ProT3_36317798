<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="<?php echo base_url('principal')?>">
    <img class="header__logo" src= "<?php echo base_url('assets/img/CP_Accesorios.png')?>" alt="Logo CD Accesorios"/>
    </a>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item active">
        <a class="nav-link" href='principal'>Inicio <span class="sr-only"></span></a>
        </li>
        <li class="nav-item active">
        <a class="nav-link" href='quienes_somos'>Quiénes somos</a>
        </li>
        <li class="nav-item active">
        <a class="nav-link" href='acerca_de'>Acerca de</a>
        </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Ingresar
        </a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href='login'>Login</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href='registro'>Registrarse</a></li>
        </ul>
        </li>
    </ul>
    <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Buscar</button>
    </form>
    </div>
</nav>