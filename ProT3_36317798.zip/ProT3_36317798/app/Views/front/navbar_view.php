<?php
$session = session();
$nombre = $session->get('nombre');
$perfil = $session->get('perfil_id');
?>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="<?php echo base_url('principal')?>">
        <img class="header__logo" src="<?php echo base_url('assets/img/CP_Accesorios.png')?>" alt="Logo CD Accesorios"/>
    </a>

    <?php if($perfil): ?>
        <div class="btn btn-secondary active btnUser btn-sm">
            <a href=""> <?php echo $perfil == 1 ? "ADMIN: " : "CLIENTE: "; ?> <?php echo $nombre; ?> </a>
        </div>
    <?php endif; ?>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <!-- Elementos de navegación para todos los usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('principal')?>">Inicio</a></li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url('acerca_de')?>">Acerca de</a></li>

            <!-- Elemento de navegación solo para clientes logueados -->
            <?php if($perfil == 2): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('quienes_somos')?>">Quiénes somos</a></li>
            <?php endif; ?>

            <!-- Cerrar Sesión visible solo para usuarios logueados -->
            <?php if($perfil): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('/logout');?>" tabindex="-1" aria-disabled="true">Cerrar Sesión</a></li>
            <?php endif; ?>
        </ul>

        <!-- Menú desplegable para Login y Registro solo visible para usuarios NO logueados -->
        <?php if(!$perfil): ?>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Ingresar
                    </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="<?php echo base_url('login')?>">Login</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="<?php echo base_url('registro')?>">Registrarse</a></li>
                </ul>
            </li>
        <?php endif; ?>
    </div>
</nav>
