<div>
        <h1>
          Somos
        </h1>
        <h3> una familia que busca ofrecer lo mejor. Desde la atención hasta la calidad de nuestros materiales.</h3>
      </div>
        <div class="seccionFirst">
            <img class="seccionFirst__img" src="assets/img/Talles.png" alt="Tabla-de-talles">
            <div class="seccionFirst__info">
                <h2 id="Nuestros">Nuestros productos</h2>
                <div class="seccionFirst__info__product-single__skills"> 
                    <div class="seccionFirst__info__product-single__skills__item">
                        <img src="assets/img/product_skill_SILVER925.svg" alt="Plata de 925 - CDAccesorios" class="hd">
                        <span>Plata<br>925</span>
                    </div>        
                    <div class="seccionFirst__info__product-single__skills__item">
                        <img src="assets/img/product_skill_HANDMADE.svg" alt="Hecho a mano - CDAccesorios" class="hd">
                        <span>Hecho <br>para ti</span>
                    </div>
                    <div class="seccionFirst__info__product-single__skills__item">
                        <img src="assets/img/product_skill_GUARANTEE.svg" alt="Garantía de 1 año - CDAccesorios" class="hd">
                        <span>Garantía <br>de 1 año</span>
                    </div>
                    <div class="seccionFirst__info__product-single__skills__item">
                        <img src="assets/img/product_skill_PAYMENT.svg" alt="Pago seguro - CDAccesorios" class="hd">
                        <span>Pago seguro</span>
                    </div>
                    <div class="seccionFirst__info__product-single__skills__item">
                        <img src="assets/img/product_skill_PACKAGING.svg" alt="Packaging sostenible - CDAccesorios" class="hd">
                        <span>Packaging <br>de regalo</span>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <!--Aquí irá enlaces a las categorías de los productos-->
        </div> 
        <section id="galeria" class="container">
            <div class="text-center pt-5">
                <h3 id="Anillos">Anillos</h3>
            </div>
            <div class="row">
                <div class="col-lg-4 col-nd-6 col-sn-12">
                    <div class="card" style="width: 18rem;">
                        <img src="assets/img/Art alas.jpg" class="card-img-top" alt="Articulo1">
                        <div class="card-body">
                        <h5 class="card-title">Anillo1</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">Ir a ver</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-nd-6 col-sn-12">
                    <div class="card" style="width: 18rem;">
                        <img src="assets/img/art piscis.jpeg" class="card-img-top" alt="Articulo2">
                        <div class="card-body">
                        <h5 class="card-title">Anillo2</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">Ir a ver</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-nd-6 col-sn-12">
                    <div class="card" style="width: 18rem;">
                        <img src="assets/img/Artcora.jpg" class="card-img-top" alt="Articulo3">
                        <div class="card-body">
                        <h5 class="card-title">Anillo3</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">Ir a ver</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>