<section class="section-contact container-fluid"> 
    <h2 id="contacto0">Contactate con nosotros:</h2>
    <form class="form">
        <div class="row">
        <div class="col">
            <input type="text" class="form-control" placeholder="Nombre">
        </div>
        <div class="col">
            <input type="text" class="form-control" placeholder="Apellido">
        </div>
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Correo Electrónico</label>
            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="nombre@ejemplo.com">
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Déjanos tu comentario, queja u opinión acá.</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
            <label class="form-check-label" for="defaultCheck1">
            Deseo recibir notificaciones en mi correo electrónico
            </label>
        </div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
</section>
<section>
    <h2 id="contacto1">Puedes visitarnos</h2>
    <div class="map-responsive">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2976.854871682318!2d-58.84019558292574!3d-27.466239568934135!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sar!4v1625930129360!5m2!1ses-419!2sar" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>>
</section>