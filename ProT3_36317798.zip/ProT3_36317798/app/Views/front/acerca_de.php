<section class="section-contact container-fluid"> 
    <div class="message-container">
        <h2>Aviso Importante</h2>
        <p>Para acceder al catálogo, necesitas registrarte y hacer login. Haz click en el botón de arriba para iniciar sesión o registrarte.
            También puedes visitarnos en nuestro local comercial y ver toda nuestra mercancía.
        </p>
</div>
</section>
<section>
    <h2 id="contacto1">Puedes visitarnos</h2>
    <div class="map-responsive">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d2976.854871682318!2d-58.84019558292574!3d-27.466239568934135!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sar!4v1625930129360!5m2!1ses-419!2sar" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>>
</section>