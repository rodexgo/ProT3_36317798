<main>
      <div>
        <img class= "Titulo" src="assets/img/cdaccesorios-bienvenida.gif" alt="gif">
      </div>
      <div class="SeccionOne">
          <div>
              <a class="SeccionOne__P1" href="#">
                <img src="assets/img/art (6).jpeg" alt="Anillos"> Anillos
              </a>
          </div>
          <div>
              <a  class="SeccionOne__P2" href="#">
                <img src="assets/img/art (10).jpeg" alt="Aros"> Aros
              </a>
          </div> 
          <div>
              <a  class="SeccionOne__P3" href="#">
                <img src="assets/img/art (8).jpeg" alt="Otros"> Otros
              </a>
          </div>        
      </div>
      <section>
          <div class="SeccionTwoTitulo">
              <h2 id="index0">Promociones</h2>
              <h3 id="index1">Promociones en nuestra tienda física</h3>
          </div>
          <div class="SeccionTwo">
              <div class="SeccionTwo__P1">
                <img src="assets/img/Aros.png" alt="Aros"> Aros
              </div>
              <div class="SeccionTwo__P2">
                <img src="assets/img/Anillos.png" alt="Anillos"> Anillos
              </div> 
              <div class="SeccionTwo__P3">
                <img src="assets/img/Otros.png" alt="Otros"> Otros
              </div>        
          </div>
      </section>
      <section>
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="assets/img/argollita aftan carousel.jpg" alt="First slide">
              <div class="carousel-caption d-none d-md-block">
                <div class="item6 wow animate__ animate__zoomIn animated" style="visibility: visible; animation-name: zoomIn;">
                  <span class="animate__ animate__heartBeat">$xxx</span>
                  <button type="button" class="btn btn-primary animate__ animate__zoomIn">Añadir al carrito</button>
                </div>
                <h5>argollita aftan</h5>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="assets/img/pulsera-corazon-2-cdaccesorios.jpg" alt="Second slide">
              <div class="carousel-caption d-none d-md-block">
                <div class="item6 wow animate__ animate__zoomIn animated" style="visibility: visible; animation-name: zoomIn;">
                  <span class="animate__ animate__heartBeat">$xxx</span>
                  <button type="button" class="btn btn-primary animate__ animate__zoomIn">Añadir al carrito</button>
                </div>
                <h5>pulsera corazón</h5>
              </div>
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="assets/img/collar Suanito love apaisado.jpg" alt="Third slide">
              <div class="carousel-caption d-none d-md-block">
                <div class="item6 wow animate__ animate__zoomIn animated" style="visibility: visible; animation-name: zoomIn;">
                  <span class="animate__ animate__heartBeat">$xxx</span>
                  <button type="button" class="btn btn-primary animate__ animate__zoomIn">Añadir al carrito</button>
                </div>
                <h5>collar y dije Susanito Love</h5>
              </div>
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Anterior</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Siguiente</span>
          </button>
        </div>
        
      </section>
    </main>