<footer>
        <ul class="socialMedia">
            <li><a href="#"><img src="assets/img/facebook.svg" alt="Facebook"></a></li> 
            <li><a href="#"><img src="assets/img/instagram.svg" alt="Instagram"></a></li>  
            <li><a href="#"><img src="assets/img/whatsapp.svg" alt="Whatsapp"></a></li> 
            <li><a href="#"><img src="assets/img/phone-call.svg" alt="Télefono"></a></li>
            <li><a href="Pages/Contacto.html"><img src="assets/img/email.svg" alt="Email"></a></li>
        </ul>   
        <div class="LeyendaFoot">
            <p>Copyright CD Accesorios - 2024. Todos los derechos reservados. | © Developed by Rodrigo González</p>
        </div> 
</footer>
<script src="assets/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>