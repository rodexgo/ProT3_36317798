<?php
namespace App\Filters;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Fi1ters\FilterInterface;

class Auth implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)

//si el usuario no está logueado
    if(!session()->get('logged_in')){
        //entonces redirecciona a la página de login 
        return redirect()->to('/login');
    }
}

public function after(RequestInterface $request, Responselnterface $response, $arguments = null)
{
    //Do sometime here
}

